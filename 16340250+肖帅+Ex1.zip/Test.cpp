#include "Test.h"
#include <cmath>

Test::Test()
{
	Img.load_bmp("1.bmp"); //��������ͼƬ
}


Test::~Test()
{
}

void Test::Imgdisplay() //ͼƬ��ʾ
{
	Img.display();
}

void Test::Colorchange() //�ױ�죬�ڱ���
{
	cimg_forXY(Img, x, y) //������ش���
	{
		if (Img(x, y, 0) == 255 && Img(x, y, 1) == 255 && Img(x, y, 2) == 255) //��ɫ��
		{
			Img(x, y, 1) = 0;
			Img(x, y, 2) = 0; //���ɫ
		}
		if (Img(x, y, 0) == 0 && Img(x, y, 1) == 0 && Img(x, y, 2) == 0) //��ɫ
		{
			Img(x, y, 1) = 255; //����ɫ
		}
	}
}

void Test::Bluecircle() //����Ȧ
{
	cimg_forXY(Img, x, y)
	{
		if ((x - 50)*(x - 50) + (y - 50)*(y - 50) <= 900)
		{
			Img(x, y, 0) = 0;
			Img(x, y, 1) = 0;
			Img(x, y, 2) = 225;
		}
	}
}


void Test::Yellowcircle()//����Ȧ
{
	cimg_forXY(Img, x, y)
	{
		if ((x - 50)*(x - 50) + (y - 50)*(y - 50) <= 9)
		{
			Img(x, y, 0) = 225;
			Img(x, y, 1) = 225;
			Img(x, y, 2) = 0;
		}
	}
}
void Test::Linepaint() //��ֱ��
{
	int l_x = (int)(100 * cos(35.0*PI / 180.0));//���x
	int l_y = (int)(100 * sin(35.0*PI / 180.0));
	int l_t = (int)(15 * tan(35.0*PI / 180.0));
	cimg_forXY(Img, x, y)
	{
		if (x == 0 && y == 0)
		{
			Img(x, y, 0) = 0;
			Img(x, y, 1) = 0;
			Img(x, y, 2) = 225;
		}
		else if (x!=0 && x <= l_x && y <= l_y)
		{
			int t = (int)(15 * y / x);
			if (t == l_t)
			{
				Img(x, y, 0) = 0;
				Img(x, y, 1) = 0;
				Img(x, y, 2) = 225;
			}
		}
	}
}

//ʹ���ڲ���������������Ϻ�����
void Test::Fun_Bluecircle()
{
	unsigned char blue[] = { 0, 0, 255 };
	Img.draw_circle(50, 50, 30, blue);
}

void Test::Fun_Yellowcircle()
{
	unsigned char yellow[] = { 255, 255, 0 };
	Img.draw_circle(50, 50, 3,yellow);
}

void Test::Fun_Linepaint()
{
	unsigned char blue[] = { 0, 0, 255 };
	Img.draw_line(0, 0, (int)(100 * cos(35 * PI / 180)), (int)(100 * sin(35 * PI / 180)), blue);
}

CImg<unsigned char> Test::GetImg() //get Img
{
	return Img;
}